<template>
  <div>
    hello I am index
  </div>
</template>

<script>
  export default {
    name: 'index',
    data() {
      return {

      }
    }
  }
</script>

<style scoped>

</style>
